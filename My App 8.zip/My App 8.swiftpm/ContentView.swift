import SwiftUI

// MARK: - MAIN APP

struct ContentView: View {
    @State private var selectedDate = Date()
    @State private var showNewEntrySheet = false
    @State private var showArchive = false
    @State private var selectedTheme: AppTheme = .pinkDream
    
    @State private var entries: [JournalEntry] = [
        JournalEntry(
            title: "A Soft Start",
            text: "Today felt calm and pretty. I spent time organizing my thoughts and making everything feel a little more peaceful.",
            date: Date(),
            mood: .calm,
            colorStyle: .pink,
            fontStyle: .rounded,
            isFavorite: true,
            isArchived: false,
            song: "Golden Hour - JVKE",
            photoName: "sparkles"
        ),
        JournalEntry(
            title: "A Tired But Good Day",
            text: "I had a lot to do, but I still got through the day. I want to remember that not every productive day has to feel perfect.",
            date: Calendar.current.date(byAdding: .day, value: -1, to: Date()) ?? Date(),
            mood: .tired,
            colorStyle: .lavender,
            fontStyle: .serif,
            isFavorite: false,
            isArchived: false,
            song: "Saturn - SZA",
            photoName: "moon.stars.fill"
        ),
        JournalEntry(
            title: "Tiny Wins",
            text: "I actually felt proud of myself today. Even the small things count, and I want to keep track of them more often.",
            date: Calendar.current.date(byAdding: .day, value: -2, to: Date()) ?? Date(),
            mood: .happy,
            colorStyle: .peach,
            fontStyle: .rounded,
            isFavorite: false,
            isArchived: false,
            song: "Feather - Sabrina Carpenter",
            photoName: "heart.fill"
        )
    ]
    
    var activeEntries: [JournalEntry] {
        entries.filter { !$0.isArchived }
            .sorted { $0.date > $1.date }
    }
    
    var body: some View {
        NavigationStack {
            ZStack {
                selectedTheme.background.ignoresSafeArea()
                
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 20) {
                        
                        // Header
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text("MoodCalendar")
                                    .font(.system(size: 32, weight: .bold, design: .rounded))
                                    .foregroundStyle(selectedTheme.primaryText)
                                
                                Text("Your thoughts, moods, and memories")
                                    .font(.subheadline)
                                    .foregroundStyle(selectedTheme.secondaryText)
                            }
                            
                            Spacer()
                            
                            Menu {
                                ForEach(AppTheme.allCases) { theme in
                                    Button(theme.rawValue) {
                                        selectedTheme = theme
                                    }
                                }
                            } label: {
                                Image(systemName: "paintpalette.fill")
                                    .font(.title2)
                                    .foregroundStyle(selectedTheme.accent)
                                    .padding(12)
                                    .background(.white.opacity(0.75))
                                    .clipShape(Circle())
                            }
                        }
                        .padding(.horizontal)
                        .padding(.top, 12)
                        
                        // Calendar Card
                        VStack(spacing: 14) {
                            HStack {
                                Text("Calendar")
                                    .font(.title3.bold())
                                    .foregroundStyle(selectedTheme.primaryText)
                                Spacer()
                                Text(monthYearString(from: selectedDate))
                                    .font(.subheadline.weight(.medium))
                                    .foregroundStyle(selectedTheme.secondaryText)
                            }
                            
                            DatePicker(
                                "",
                                selection: $selectedDate,
                                displayedComponents: [.date]
                            )
                            .datePickerStyle(.graphical)
                            .labelsHidden()
                            .accentColor(selectedTheme.accent)
                            .colorScheme(.light)
                            .padding(8)
                            .background(
                                RoundedRectangle(cornerRadius: 22)
                                    .fill(Color.white.opacity(0.96))
                            )
                        }
                        .padding()
                        .background(.white.opacity(0.82))
                        .clipShape(RoundedRectangle(cornerRadius: 28))
                        .padding(.horizontal)
                        
                        // Buttons
                        HStack(spacing: 14) {
                            Button {
                                showNewEntrySheet = true
                            } label: {
                                HStack {
                                    Image(systemName: "square.and.pencil")
                                    Text("New Entry")
                                        .fontWeight(.semibold)
                                }
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(selectedTheme.accent)
                                .foregroundStyle(.white)
                                .clipShape(RoundedRectangle(cornerRadius: 20))
                            }
                            
                            Button {
                                showArchive = true
                            } label: {
                                HStack {
                                    Image(systemName: "archivebox.fill")
                                    Text("Archive")
                                        .fontWeight(.semibold)
                                }
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(.white.opacity(0.82))
                                .foregroundStyle(selectedTheme.primaryText)
                                .clipShape(RoundedRectangle(cornerRadius: 20))
                            }
                        }
                        .padding(.horizontal)
                        
                        // Section Title
                        HStack {
                            Text("Recent Entries")
                                .font(.title3.bold())
                                .foregroundStyle(selectedTheme.primaryText)
                            Spacer()
                        }
                        .padding(.horizontal)
                        
                        // Entry Cards
                        VStack(spacing: 16) {
                            ForEach(activeEntries) { entry in
                                EntryCardView(
                                    entry: entry,
                                    theme: selectedTheme,
                                    onFavoriteToggle: {
                                        toggleFavorite(for: entry)
                                    },
                                    onArchive: {
                                        archiveEntry(entry)
                                    }
                                )
                            }
                        }
                        .padding(.horizontal)
                        .padding(.bottom, 30)
                    }
                }
            }
            .sheet(isPresented: $showNewEntrySheet) {
                NewEntryView(entries: $entries, selectedTheme: selectedTheme)
            }
            .sheet(isPresented: $showArchive) {
                ArchiveView(entries: $entries, theme: selectedTheme)
            }
        }
    }
    
    func toggleFavorite(for entry: JournalEntry) {
        if let index = entries.firstIndex(where: { $0.id == entry.id }) {
            entries[index].isFavorite.toggle()
        }
    }
    
    func archiveEntry(_ entry: JournalEntry) {
        if let index = entries.firstIndex(where: { $0.id == entry.id }) {
            entries[index].isArchived = true
        }
    }
    
    func monthYearString(from date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMMM yyyy"
        return formatter.string(from: date)
    }
}

// MARK: - ENTRY CARD

struct EntryCardView: View {
    let entry: JournalEntry
    let theme: AppTheme
    let onFavoriteToggle: () -> Void
    let onArchive: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .top) {
                HStack(spacing: 10) {
                    Text(entry.mood.emoji)
                        .font(.system(size: 28))
                    
                    VStack(alignment: .leading, spacing: 4) {
                        Text(entry.title)
                            .font(entry.fontStyle.titleFont)
                            .foregroundStyle(theme.primaryText)
                        
                        Text(formattedDate(entry.date))
                            .font(.caption)
                            .foregroundStyle(theme.secondaryText)
                    }
                }
                
                Spacer()
                
                VStack(spacing: 10) {
                    Button {
                        onFavoriteToggle()
                    } label: {
                        Image(systemName: entry.isFavorite ? "heart.fill" : "heart")
                            .foregroundStyle(entry.isFavorite ? .pink : theme.secondaryText)
                    }
                    
                    Button {
                        onArchive()
                    } label: {
                        Image(systemName: "archivebox")
                            .foregroundStyle(theme.secondaryText)
                    }
                }
                .font(.title3)
            }
            
            Text(entry.text)
                .font(entry.fontStyle.bodyFont)
                .foregroundStyle(entry.colorStyle.textColor)
                .lineSpacing(5)
            
            if let song = entry.song, !song.isEmpty {
                HStack(spacing: 8) {
                    Image(systemName: "music.note")
                    Text(song)
                        .font(.subheadline)
                }
                .foregroundStyle(theme.secondaryText)
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(entry.colorStyle.softBackground)
                .clipShape(Capsule())
            }
            
            if let photoName = entry.photoName {
                ZStack {
                    RoundedRectangle(cornerRadius: 22)
                        .fill(entry.colorStyle.softBackground)
                        .frame(height: 130)
                    
                    VStack(spacing: 10) {
                        Image(systemName: photoName)
                            .font(.system(size: 38))
                            .foregroundStyle(entry.colorStyle.textColor)
                        Text("Memory Photo")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(theme.secondaryText)
                    }
                }
            }
        }
        .padding(18)
        .background(.white.opacity(0.88))
        .clipShape(RoundedRectangle(cornerRadius: 28))
        .shadow(color: .black.opacity(0.04), radius: 10, x: 0, y: 4)
    }
    
    func formattedDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM d, yyyy"
        return formatter.string(from: date)
    }
}

// MARK: - NEW ENTRY VIEW

struct NewEntryView: View {
    @Environment(\.dismiss) private var dismiss
    @Binding var entries: [JournalEntry]
    
    let selectedTheme: AppTheme
    
    @State private var title = ""
    @State private var text = ""
    @State private var selectedMood: MoodSticker = .happy
    @State private var selectedColor: EntryColorStyle = .pink
    @State private var selectedFont: EntryFontStyle = .rounded
    @State private var isBold = false
    @State private var isItalic = false
    @State private var isUnderlined = false
    @State private var textSize: CGFloat = 18
    @State private var selectedDate = Date()
    @State private var song = ""
    @State private var wantsPhoto = false
    @State private var selectedPhotoSymbol = "photo.on.rectangle.angled"
    
    let cutePhotoSymbols = [
        "sparkles",
        "heart.fill",
        "moon.stars.fill",
        "sun.max.fill",
        "cloud.sun.fill",
        "camera.fill",
        "photo.on.rectangle.angled"
    ]
    
    var body: some View {
        NavigationStack {
            ZStack {
                selectedTheme.background.ignoresSafeArea()
                
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 18) {
                        
                        // Mood Picker
                        sectionCard(title: "Pick Your Mood") {
                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack(spacing: 14) {
                                    ForEach(MoodSticker.allCases) { mood in
                                        Button {
                                            selectedMood = mood
                                        } label: {
                                            VStack(spacing: 8) {
                                                Text(mood.emoji)
                                                    .font(.system(size: 34))
                                                Text(mood.rawValue)
                                                    .font(.caption)
                                                    .foregroundStyle(selectedTheme.primaryText)
                                            }
                                            .padding()
                                            .frame(width: 88)
                                            .background(
                                                selectedMood == mood
                                                ? selectedTheme.accent.opacity(0.25)
                                                : .white.opacity(0.8)
                                            )
                                            .clipShape(RoundedRectangle(cornerRadius: 20))
                                        }
                                    }
                                }
                                .padding(.horizontal, 2)
                            }
                        }
                        
                        // Title and Date
                        sectionCard(title: "Entry Details") {
                            VStack(spacing: 14) {
                                TextField("Entry Title", text: $title)
                                    .padding()
                                    .background(.white.opacity(0.9))
                                    .clipShape(RoundedRectangle(cornerRadius: 18))
                                
                                DatePicker("Date", selection: $selectedDate, displayedComponents: [.date])
                                    .padding()
                                    .background(.white.opacity(0.9))
                                    .clipShape(RoundedRectangle(cornerRadius: 18))
                            }
                        }
                        
                        // Text Tools
                        sectionCard(title: "Text Style") {
                            VStack(spacing: 14) {
                                
                                ScrollView(.horizontal, showsIndicators: false) {
                                    HStack(spacing: 10) {
                                        ForEach(EntryColorStyle.allCases) { colorStyle in
                                            Button {
                                                selectedColor = colorStyle
                                            } label: {
                                                Text(colorStyle.rawValue)
                                                    .font(.subheadline.weight(.medium))
                                                    .padding(.horizontal, 14)
                                                    .padding(.vertical, 10)
                                                    .background(selectedColor.softBackground)
                                                    .overlay(
                                                        RoundedRectangle(cornerRadius: 16)
                                                            .stroke(
                                                                selectedColor == colorStyle ? colorStyle.textColor : .clear,
                                                                lineWidth: 2
                                                            )
                                                    )
                                                    .clipShape(RoundedRectangle(cornerRadius: 16))
                                            }
                                        }
                                    }
                                }
                                
                                ScrollView(.horizontal, showsIndicators: false) {
                                    HStack(spacing: 10) {
                                        ForEach(EntryFontStyle.allCases) { font in
                                            Button {
                                                selectedFont = font
                                            } label: {
                                                Text(font.rawValue)
                                                    .font(font.bodyFont)
                                                    .padding(.horizontal, 14)
                                                    .padding(.vertical, 10)
                                                    .background(.white.opacity(0.9))
                                                    .overlay(
                                                        RoundedRectangle(cornerRadius: 16)
                                                            .stroke(
                                                                selectedFont == font ? selectedTheme.accent : .clear,
                                                                lineWidth: 2
                                                            )
                                                    )
                                                    .clipShape(RoundedRectangle(cornerRadius: 16))
                                            }
                                        }
                                    }
                                }
                                
                                HStack(spacing: 12) {
                                    styleButton(title: "B", isSelected: isBold) {
                                        isBold.toggle()
                                    }
                                    
                                    styleButton(title: "I", isSelected: isItalic) {
                                        isItalic.toggle()
                                    }
                                    
                                    styleButton(title: "U", isSelected: isUnderlined) {
                                        isUnderlined.toggle()
                                    }
                                    
                                    Spacer()
                                }
                                
                                VStack(alignment: .leading, spacing: 8) {
                                    Text("Text Size")
                                        .font(.subheadline.weight(.medium))
                                        .foregroundStyle(selectedTheme.primaryText)
                                    
                                    Slider(value: $textSize, in: 14...28)
                                        .tint(selectedTheme.accent)
                                }
                            }
                        }
                        
                        // Writing Area
                        sectionCard(title: "Write Something") {
                            VStack(spacing: 12) {
                                ZStack(alignment: .topLeading) {
                                    RoundedRectangle(cornerRadius: 24)
                                        .fill(.white.opacity(0.9))
                                        .frame(minHeight: 220)
                                    
                                    if text.isEmpty {
                                        Text("Write your thoughts here...")
                                            .foregroundStyle(.gray.opacity(0.7))
                                            .padding(.horizontal, 18)
                                            .padding(.top, 16)
                                    }
                                    
                                    TextEditor(text: $text)
                                        .font(customEditorFont())
                                        .foregroundColor(selectedColor.textColor)
                                        .scrollContentBackground(.hidden)
                                        .padding(12)
                                        .frame(minHeight: 220)
                                        .background(Color.clear)
                                }
                                
                                if isUnderlined || isBold || isItalic {
                                    Text("Preview style: \(previewStyleText())")
                                        .font(.caption)
                                        .foregroundStyle(selectedTheme.secondaryText)
                                }
                            }
                        }
                        
                        // Optional Extras
                        sectionCard(title: "Optional Extras") {
                            VStack(spacing: 14) {
                                TextField("Song of the Day", text: $song)
                                    .padding()
                                    .background(.white.opacity(0.9))
                                    .clipShape(RoundedRectangle(cornerRadius: 18))
                                
                                Toggle("Add Cute Photo Card", isOn: $wantsPhoto)
                                    .tint(selectedTheme.accent)
                                
                                if wantsPhoto {
                                    ScrollView(.horizontal, showsIndicators: false) {
                                        HStack(spacing: 12) {
                                            ForEach(cutePhotoSymbols, id: \.self) { symbol in
                                                Button {
                                                    selectedPhotoSymbol = symbol
                                                } label: {
                                                    VStack {
                                                        Image(systemName: symbol)
                                                            .font(.system(size: 28))
                                                            .foregroundStyle(selectedColor.textColor)
                                                            .frame(width: 64, height: 64)
                                                            .background(selectedColor.softBackground)
                                                            .clipShape(RoundedRectangle(cornerRadius: 18))
                                                    }
                                                    .overlay(
                                                        RoundedRectangle(cornerRadius: 18)
                                                            .stroke(
                                                                selectedPhotoSymbol == symbol ? selectedTheme.accent : .clear,
                                                                lineWidth: 2
                                                            )
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    .padding()
                    .padding(.bottom, 30)
                }
            }
            .navigationTitle("New Entry")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Close") {
                        dismiss()
                    }
                    .foregroundStyle(selectedTheme.primaryText)
                }
                
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Save") {
                        saveEntry()
                    }
                    .fontWeight(.bold)
                    .foregroundStyle(selectedTheme.accent)
                }
            }
        }
    }
    
    func sectionCard<Content: View>(title: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            Text(title)
                .font(.title3.bold())
                .foregroundStyle(selectedTheme.primaryText)
            
            content()
        }
        .padding()
        .background(.white.opacity(0.78))
        .clipShape(RoundedRectangle(cornerRadius: 28))
    }
    
    func styleButton(title: String, isSelected: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 18, weight: .bold, design: .rounded))
                .frame(width: 46, height: 46)
                .background(isSelected ? selectedTheme.accent.opacity(0.25) : .white.opacity(0.9))
                .foregroundStyle(selectedTheme.primaryText)
                .clipShape(RoundedRectangle(cornerRadius: 14))
        }
    }
    
    func customEditorFont() -> Font {
        selectedFont.bodyFont
    }
    
    func previewStyleText() -> String {
        var styles: [String] = []
        if isBold { styles.append("Bold") }
        if isItalic { styles.append("Italic") }
        if isUnderlined { styles.append("Underline") }
        return styles.joined(separator: " • ")
    }
    
    func uiColor(from color: Color) -> UIColor {
        UIColor(color)
    }
    
    func saveEntry() {
        let finalTitle = title.isEmpty ? "Untitled Entry" : title
        let finalText = text.isEmpty ? "A quiet little thought for today." : text
        
        let newEntry = JournalEntry(
            title: finalTitle,
            text: finalText,
            date: selectedDate,
            mood: selectedMood,
            colorStyle: selectedColor,
            fontStyle: selectedFont,
            isFavorite: false,
            isArchived: false,
            song: song.isEmpty ? nil : song,
            photoName: wantsPhoto ? selectedPhotoSymbol : nil
        )
        
        entries.insert(newEntry, at: 0)
        dismiss()
    }
}

// MARK: - ARCHIVE VIEW

struct ArchiveView: View {
    @Environment(\.dismiss) private var dismiss
    @Binding var entries: [JournalEntry]
    let theme: AppTheme
    
    var archivedEntries: [JournalEntry] {
        entries.filter { $0.isArchived }
    }
    
    var body: some View {
        NavigationStack {
            ZStack {
                theme.background.ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 16) {
                        if archivedEntries.isEmpty {
                            VStack(spacing: 14) {
                                Image(systemName: "archivebox")
                                    .font(.system(size: 48))
                                    .foregroundStyle(theme.secondaryText)
                                
                                Text("No archived entries yet")
                                    .font(.title3.bold())
                                    .foregroundStyle(theme.primaryText)
                                
                                Text("Entries you archive will appear here.")
                                    .font(.subheadline)
                                    .foregroundStyle(theme.secondaryText)
                            }
                            .padding(.top, 80)
                        } else {
                            ForEach(archivedEntries) { entry in
                                VStack(alignment: .leading, spacing: 12) {
                                    HStack {
                                        Text("\(entry.mood.emoji) \(entry.title)")
                                            .font(entry.fontStyle.titleFont)
                                            .foregroundStyle(theme.primaryText)
                                        Spacer()
                                        
                                        Button("Restore") {
                                            restore(entry)
                                        }
                                        .font(.subheadline.weight(.semibold))
                                        .foregroundStyle(theme.accent)
                                    }
                                    
                                    Text(entry.text)
                                        .font(entry.fontStyle.bodyFont)
                                        .foregroundStyle(entry.colorStyle.textColor)
                                }
                                .padding()
                                .background(.white.opacity(0.85))
                                .clipShape(RoundedRectangle(cornerRadius: 24))
                            }
                        }
                    }
                    .padding()
                }
            }
            .navigationTitle("Archive")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Close") {
                        dismiss()
                    }
                    .foregroundStyle(theme.primaryText)
                }
            }
        }
    }
    
    func restore(_ entry: JournalEntry) {
        if let index = entries.firstIndex(where: { $0.id == entry.id }) {
            entries[index].isArchived = false
        }
    }
}

// MARK: - MODELS

struct JournalEntry: Identifiable {
    let id = UUID()
    var title: String
    var text: String
    var date: Date
    var mood: MoodSticker
    var colorStyle: EntryColorStyle
    var fontStyle: EntryFontStyle
    var isFavorite: Bool
    var isArchived: Bool
    var song: String?
    var photoName: String?
}

enum MoodSticker: String, CaseIterable, Identifiable {
    case happy = "Happy"
    case sad = "Sad"
    case tired = "Tired"
    case excited = "Excited"
    case calm = "Calm"
    case angry = "Angry"
    case stressed = "Stressed"
    case silly = "Silly"
    
    var id: String { rawValue }
    
    var emoji: String {
        switch self {
        case .happy: return "😊"
        case .sad: return "😢"
        case .tired: return "😴"
        case .excited: return "🤩"
        case .calm: return "😌"
        case .angry: return "😡"
        case .stressed: return "😰"
        case .silly: return "🤪"
        }
    }
}

enum EntryColorStyle: String, CaseIterable, Identifiable {
    case pink = "Pink"
    case lavender = "Lavender"
    case peach = "Peach"
    case mint = "Mint"
    case sky = "Sky"
    
    var id: String { rawValue }
    
    var textColor: Color {
        switch self {
        case .pink: return Color(red: 0.82, green: 0.38, blue: 0.58)
        case .lavender: return Color(red: 0.53, green: 0.45, blue: 0.80)
        case .peach: return Color(red: 0.87, green: 0.49, blue: 0.36)
        case .mint: return Color(red: 0.29, green: 0.67, blue: 0.58)
        case .sky: return Color(red: 0.31, green: 0.57, blue: 0.84)
        }
    }
    
    var softBackground: Color {
        switch self {
        case .pink: return Color(red: 1.0, green: 0.91, blue: 0.95)
        case .lavender: return Color(red: 0.94, green: 0.91, blue: 1.0)
        case .peach: return Color(red: 1.0, green: 0.92, blue: 0.87)
        case .mint: return Color(red: 0.89, green: 0.98, blue: 0.94)
        case .sky: return Color(red: 0.89, green: 0.95, blue: 1.0)
        }
    }
}

enum EntryFontStyle: String, CaseIterable, Identifiable {
    case rounded = "Rounded"
    case serif = "Serif"
    case elegant = "Elegant"
    
    var id: String { rawValue }
    
    var titleFont: Font {
        switch self {
        case .rounded:
            return .system(size: 22, weight: .bold, design: .rounded)
        case .serif:
            return .system(size: 22, weight: .bold, design: .serif)
        case .elegant:
            return .system(size: 22, weight: .semibold, design: .default)
        }
    }
    
    var bodyFont: Font {
        switch self {
        case .rounded:
            return .system(size: 17, weight: .regular, design: .rounded)
        case .serif:
            return .system(size: 17, weight: .regular, design: .serif)
        case .elegant:
            return .system(size: 17, weight: .regular, design: .default)
        }
    }
}

enum AppTheme: String, CaseIterable, Identifiable {
    case pinkDream = "Pink Dream"
    case matchaGreen = "Matcha Green"
    case sunsetPeach = "Sunset Peach"
    case lavenderCloud = "Lavender Cloud"
    case midnightBlue = "Midnight Blue"
    case cleanWhite = "Clean White"
    
    var id: String { rawValue }
    
    var background: LinearGradient {
        switch self {
        case .pinkDream:
            return LinearGradient(
                colors: [Color(red: 1.0, green: 0.94, blue: 0.97), Color(red: 1.0, green: 0.89, blue: 0.93)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        case .matchaGreen:
            return LinearGradient(
                colors: [Color(red: 0.93, green: 0.98, blue: 0.94), Color(red: 0.85, green: 0.95, blue: 0.88)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        case .sunsetPeach:
            return LinearGradient(
                colors: [Color(red: 1.0, green: 0.95, blue: 0.90), Color(red: 1.0, green: 0.87, blue: 0.82)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        case .lavenderCloud:
            return LinearGradient(
                colors: [Color(red: 0.96, green: 0.94, blue: 1.0), Color(red: 0.90, green: 0.88, blue: 0.98)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        case .midnightBlue:
            return LinearGradient(
                colors: [Color(red: 0.88, green: 0.92, blue: 1.0), Color(red: 0.80, green: 0.86, blue: 0.98)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        case .cleanWhite:
            return LinearGradient(
                colors: [Color.white, Color(red: 0.96, green: 0.97, blue: 1.0)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        }
    }
    
    var accent: Color {
        switch self {
        case .pinkDream: return Color(red: 0.93, green: 0.47, blue: 0.67)
        case .matchaGreen: return Color(red: 0.43, green: 0.71, blue: 0.55)
        case .sunsetPeach: return Color(red: 0.96, green: 0.57, blue: 0.46)
        case .lavenderCloud: return Color(red: 0.63, green: 0.54, blue: 0.90)
        case .midnightBlue: return Color(red: 0.42, green: 0.58, blue: 0.88)
        case .cleanWhite: return Color(red: 0.60, green: 0.66, blue: 0.88)
        }
    }
    
    var primaryText: Color {
        Color(red: 0.25, green: 0.25, blue: 0.30)
    }
    
    var secondaryText: Color {
        Color(red: 0.45, green: 0.45, blue: 0.52)
    }
}

// MARK: - PREVIEW

#Preview {
    ContentView()
}

